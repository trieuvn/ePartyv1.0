﻿namespace eParty
{
    partial class Registration
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registration));
            panel1 = new Panel();
            btnExit = new Button();
            pictureBox1 = new PictureBox();
            lbRegistration = new Label();
            btnstarted = new Button();
            pictureBox2 = new PictureBox();
            txtEmail = new TextBox();
            label1 = new Label();
            lbEmail = new Label();
            txtFullname = new TextBox();
            pictureBox3 = new PictureBox();
            label2 = new Label();
            label3 = new Label();
            txtPass = new TextBox();
            pictureBox4 = new PictureBox();
            label4 = new Label();
            label5 = new Label();
            txtConfirmPass = new TextBox();
            pictureBox5 = new PictureBox();
            label6 = new Label();
            label7 = new Label();
            pictureBox6 = new PictureBox();
            label8 = new Label();
            label9 = new Label();
            txtusername = new TextBox();
            txtphone = new TextBox();
            pictureBox7 = new PictureBox();
            label10 = new Label();
            label11 = new Label();
            pictureBox8 = new PictureBox();
            label12 = new Label();
            label13 = new Label();
            txtAddress = new TextBox();
            timer1 = new System.Windows.Forms.Timer(components);
            panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).BeginInit();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.FromArgb(41, 128, 182);
            panel1.Controls.Add(btnExit);
            panel1.Controls.Add(pictureBox1);
            panel1.Controls.Add(lbRegistration);
            panel1.Dock = DockStyle.Top;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4, 5, 4, 5);
            panel1.Name = "panel1";
            panel1.Size = new Size(377, 178);
            panel1.TabIndex = 0;
            panel1.UseWaitCursor = true;
            panel1.Paint += panel1_Paint;
            // 
            // btnExit
            // 
            btnExit.Cursor = Cursors.WaitCursor;
            btnExit.FlatAppearance.BorderSize = 0;
            btnExit.FlatAppearance.MouseOverBackColor = Color.Red;
            btnExit.FlatStyle = FlatStyle.Flat;
            btnExit.Font = new Font("Verdana", 13.875F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnExit.ForeColor = Color.White;
            btnExit.Location = new Point(344, 3);
            btnExit.Name = "btnExit";
            btnExit.Size = new Size(33, 40);
            btnExit.TabIndex = 5;
            btnExit.Text = "X";
            btnExit.UseVisualStyleBackColor = true;
            btnExit.UseWaitCursor = true;
            btnExit.Click += btnExit_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(23, 60);
            pictureBox1.Margin = new Padding(4, 5, 4, 5);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(72, 83);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.UseWaitCursor = true;
            // 
            // lbRegistration
            // 
            lbRegistration.AutoSize = true;
            lbRegistration.Font = new Font("Malgun Gothic", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbRegistration.ForeColor = Color.White;
            lbRegistration.Location = new Point(103, 60);
            lbRegistration.Margin = new Padding(4, 0, 4, 0);
            lbRegistration.Name = "lbRegistration";
            lbRegistration.Size = new Size(204, 46);
            lbRegistration.TabIndex = 0;
            lbRegistration.Text = "Registration";
            lbRegistration.UseWaitCursor = true;
            // 
            // btnstarted
            // 
            btnstarted.BackColor = Color.FromArgb(41, 128, 182);
            btnstarted.FlatStyle = FlatStyle.Flat;
            btnstarted.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            btnstarted.ForeColor = Color.White;
            btnstarted.Location = new Point(23, 849);
            btnstarted.Margin = new Padding(4, 5, 4, 5);
            btnstarted.Name = "btnstarted";
            btnstarted.Size = new Size(339, 63);
            btnstarted.TabIndex = 1;
            btnstarted.Text = "GET STARTED";
            btnstarted.UseVisualStyleBackColor = false;
            btnstarted.UseWaitCursor = true;
            btnstarted.Click += btnstarted_Click;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(23, 215);
            pictureBox2.Margin = new Padding(4, 5, 4, 5);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(27, 31);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            pictureBox2.UseWaitCursor = true;
            // 
            // txtEmail
            // 
            txtEmail.BorderStyle = BorderStyle.None;
            txtEmail.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtEmail.Location = new Point(57, 215);
            txtEmail.Margin = new Padding(4, 5, 4, 5);
            txtEmail.Name = "txtEmail";
            txtEmail.Size = new Size(304, 27);
            txtEmail.TabIndex = 3;
            txtEmail.UseWaitCursor = true;
            txtEmail.TextChanged += txtEmail_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label1.ForeColor = Color.FromArgb(41, 128, 182);
            label1.Location = new Point(19, 240);
            label1.Margin = new Padding(4, 0, 4, 0);
            label1.Name = "label1";
            label1.Size = new Size(309, 19);
            label1.TabIndex = 4;
            label1.Text = "__________________________________________________";
            label1.UseWaitCursor = true;
            // 
            // lbEmail
            // 
            lbEmail.AutoSize = true;
            lbEmail.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            lbEmail.ForeColor = Color.FromArgb(42, 128, 182);
            lbEmail.Location = new Point(53, 183);
            lbEmail.Margin = new Padding(4, 0, 4, 0);
            lbEmail.Name = "lbEmail";
            lbEmail.Size = new Size(46, 20);
            lbEmail.TabIndex = 5;
            lbEmail.Text = "Email";
            lbEmail.UseWaitCursor = true;
            // 
            // txtFullname
            // 
            txtFullname.BorderStyle = BorderStyle.None;
            txtFullname.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtFullname.Location = new Point(57, 308);
            txtFullname.Margin = new Padding(4, 5, 4, 5);
            txtFullname.Name = "txtFullname";
            txtFullname.Size = new Size(304, 27);
            txtFullname.TabIndex = 7;
            txtFullname.UseWaitCursor = true;
            txtFullname.TextChanged += txtFullname_TextChanged;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(23, 308);
            pictureBox3.Margin = new Padding(4, 5, 4, 5);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(27, 31);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 6;
            pictureBox3.TabStop = false;
            pictureBox3.UseWaitCursor = true;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label2.ForeColor = Color.FromArgb(41, 128, 182);
            label2.Location = new Point(19, 332);
            label2.Margin = new Padding(4, 0, 4, 0);
            label2.Name = "label2";
            label2.Size = new Size(309, 19);
            label2.TabIndex = 8;
            label2.Text = "__________________________________________________";
            label2.UseWaitCursor = true;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label3.ForeColor = Color.FromArgb(42, 128, 182);
            label3.Location = new Point(53, 275);
            label3.Margin = new Padding(4, 0, 4, 0);
            label3.Name = "label3";
            label3.Size = new Size(76, 20);
            label3.TabIndex = 9;
            label3.Text = "Full name";
            label3.UseWaitCursor = true;
            // 
            // txtPass
            // 
            txtPass.BorderStyle = BorderStyle.None;
            txtPass.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtPass.Location = new Point(57, 677);
            txtPass.Margin = new Padding(4, 5, 4, 5);
            txtPass.Name = "txtPass";
            txtPass.Size = new Size(304, 27);
            txtPass.TabIndex = 11;
            txtPass.UseWaitCursor = true;
            txtPass.TextChanged += txtPass_TextChanged;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(23, 677);
            pictureBox4.Margin = new Padding(4, 5, 4, 5);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(27, 31);
            pictureBox4.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox4.TabIndex = 10;
            pictureBox4.TabStop = false;
            pictureBox4.UseWaitCursor = true;
            pictureBox4.Click += pictureBox4_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label4.ForeColor = Color.FromArgb(41, 128, 182);
            label4.Location = new Point(19, 702);
            label4.Margin = new Padding(4, 0, 4, 0);
            label4.Name = "label4";
            label4.Size = new Size(309, 19);
            label4.TabIndex = 12;
            label4.Text = "__________________________________________________";
            label4.UseWaitCursor = true;
            label4.Click += label4_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label5.ForeColor = Color.FromArgb(42, 128, 182);
            label5.Location = new Point(53, 645);
            label5.Margin = new Padding(4, 0, 4, 0);
            label5.Name = "label5";
            label5.Size = new Size(72, 20);
            label5.TabIndex = 13;
            label5.Text = "Password";
            label5.UseWaitCursor = true;
            // 
            // txtConfirmPass
            // 
            txtConfirmPass.BorderStyle = BorderStyle.None;
            txtConfirmPass.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtConfirmPass.Location = new Point(57, 769);
            txtConfirmPass.Margin = new Padding(4, 5, 4, 5);
            txtConfirmPass.Name = "txtConfirmPass";
            txtConfirmPass.Size = new Size(304, 27);
            txtConfirmPass.TabIndex = 15;
            txtConfirmPass.UseWaitCursor = true;
            txtConfirmPass.TextChanged += textBox1_TextChanged;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(23, 769);
            pictureBox5.Margin = new Padding(4, 5, 4, 5);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(27, 31);
            pictureBox5.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox5.TabIndex = 14;
            pictureBox5.TabStop = false;
            pictureBox5.UseWaitCursor = true;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label6.ForeColor = Color.FromArgb(41, 128, 182);
            label6.Location = new Point(19, 794);
            label6.Margin = new Padding(4, 0, 4, 0);
            label6.Name = "label6";
            label6.Size = new Size(309, 19);
            label6.TabIndex = 16;
            label6.Text = "__________________________________________________";
            label6.UseWaitCursor = true;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label7.ForeColor = Color.FromArgb(42, 128, 182);
            label7.Location = new Point(53, 737);
            label7.Margin = new Padding(4, 0, 4, 0);
            label7.Name = "label7";
            label7.Size = new Size(132, 20);
            label7.TabIndex = 17;
            label7.Text = "Confirm password";
            label7.UseWaitCursor = true;
            // 
            // pictureBox6
            // 
            pictureBox6.Image = (Image)resources.GetObject("pictureBox6.Image");
            pictureBox6.Location = new Point(23, 400);
            pictureBox6.Margin = new Padding(4, 5, 4, 5);
            pictureBox6.Name = "pictureBox6";
            pictureBox6.Size = new Size(27, 31);
            pictureBox6.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox6.TabIndex = 18;
            pictureBox6.TabStop = false;
            pictureBox6.UseWaitCursor = true;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label8.ForeColor = Color.FromArgb(41, 128, 182);
            label8.Location = new Point(19, 425);
            label8.Margin = new Padding(4, 0, 4, 0);
            label8.Name = "label8";
            label8.Size = new Size(309, 19);
            label8.TabIndex = 19;
            label8.Text = "__________________________________________________";
            label8.UseWaitCursor = true;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label9.ForeColor = Color.FromArgb(42, 128, 182);
            label9.Location = new Point(53, 368);
            label9.Margin = new Padding(4, 0, 4, 0);
            label9.Name = "label9";
            label9.Size = new Size(77, 20);
            label9.TabIndex = 20;
            label9.Text = "Username";
            label9.UseWaitCursor = true;
            // 
            // txtusername
            // 
            txtusername.BorderStyle = BorderStyle.None;
            txtusername.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtusername.Location = new Point(57, 400);
            txtusername.Margin = new Padding(4, 5, 4, 5);
            txtusername.Name = "txtusername";
            txtusername.Size = new Size(304, 27);
            txtusername.TabIndex = 21;
            txtusername.UseWaitCursor = true;
            txtusername.TextChanged += txtusername_TextChanged;
            // 
            // txtphone
            // 
            txtphone.BorderStyle = BorderStyle.None;
            txtphone.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtphone.Location = new Point(57, 492);
            txtphone.Margin = new Padding(4, 5, 4, 5);
            txtphone.Name = "txtphone";
            txtphone.Size = new Size(304, 27);
            txtphone.TabIndex = 25;
            txtphone.UseWaitCursor = true;
            txtphone.TextChanged += txtphone_TextChanged;
            // 
            // pictureBox7
            // 
            pictureBox7.Image = (Image)resources.GetObject("pictureBox7.Image");
            pictureBox7.Location = new Point(23, 492);
            pictureBox7.Margin = new Padding(4, 5, 4, 5);
            pictureBox7.Name = "pictureBox7";
            pictureBox7.Size = new Size(27, 31);
            pictureBox7.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox7.TabIndex = 22;
            pictureBox7.TabStop = false;
            pictureBox7.UseWaitCursor = true;
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label10.ForeColor = Color.FromArgb(41, 128, 182);
            label10.Location = new Point(19, 517);
            label10.Margin = new Padding(4, 0, 4, 0);
            label10.Name = "label10";
            label10.Size = new Size(309, 19);
            label10.TabIndex = 23;
            label10.Text = "__________________________________________________";
            label10.UseWaitCursor = true;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label11.ForeColor = Color.FromArgb(42, 128, 182);
            label11.Location = new Point(53, 460);
            label11.Margin = new Padding(4, 0, 4, 0);
            label11.Name = "label11";
            label11.Size = new Size(111, 20);
            label11.TabIndex = 24;
            label11.Text = "Phone number";
            label11.UseWaitCursor = true;
            // 
            // pictureBox8
            // 
            pictureBox8.Image = (Image)resources.GetObject("pictureBox8.Image");
            pictureBox8.Location = new Point(23, 585);
            pictureBox8.Margin = new Padding(4, 5, 4, 5);
            pictureBox8.Name = "pictureBox8";
            pictureBox8.Size = new Size(27, 31);
            pictureBox8.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox8.TabIndex = 26;
            pictureBox8.TabStop = false;
            pictureBox8.UseWaitCursor = true;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Malgun Gothic", 8.25F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label12.ForeColor = Color.FromArgb(41, 128, 182);
            label12.Location = new Point(19, 609);
            label12.Margin = new Padding(4, 0, 4, 0);
            label12.Name = "label12";
            label12.Size = new Size(309, 19);
            label12.TabIndex = 27;
            label12.Text = "__________________________________________________";
            label12.UseWaitCursor = true;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Malgun Gothic", 9F, FontStyle.Regular, GraphicsUnit.Point, 0);
            label13.ForeColor = Color.FromArgb(42, 128, 182);
            label13.Location = new Point(53, 552);
            label13.Margin = new Padding(4, 0, 4, 0);
            label13.Name = "label13";
            label13.Size = new Size(62, 20);
            label13.TabIndex = 28;
            label13.Text = "Address";
            label13.UseWaitCursor = true;
            // 
            // txtAddress
            // 
            txtAddress.BorderStyle = BorderStyle.None;
            txtAddress.Font = new Font("Malgun Gothic", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            txtAddress.Location = new Point(57, 585);
            txtAddress.Margin = new Padding(4, 5, 4, 5);
            txtAddress.Name = "txtAddress";
            txtAddress.Size = new Size(304, 27);
            txtAddress.TabIndex = 29;
            txtAddress.UseWaitCursor = true;
            txtAddress.TextChanged += textBox2_TextChanged;
            // 
            // timer1
            // 
            timer1.Tick += timer1_Tick;
            // 
            // Registration
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.White;
            ClientSize = new Size(377, 931);
            ControlBox = false;
            Controls.Add(txtAddress);
            Controls.Add(pictureBox8);
            Controls.Add(label12);
            Controls.Add(label13);
            Controls.Add(txtphone);
            Controls.Add(pictureBox7);
            Controls.Add(label10);
            Controls.Add(label11);
            Controls.Add(txtusername);
            Controls.Add(pictureBox6);
            Controls.Add(label8);
            Controls.Add(label9);
            Controls.Add(txtConfirmPass);
            Controls.Add(pictureBox5);
            Controls.Add(label6);
            Controls.Add(label7);
            Controls.Add(txtPass);
            Controls.Add(pictureBox4);
            Controls.Add(label4);
            Controls.Add(label5);
            Controls.Add(txtFullname);
            Controls.Add(pictureBox3);
            Controls.Add(label2);
            Controls.Add(label3);
            Controls.Add(txtEmail);
            Controls.Add(pictureBox2);
            Controls.Add(btnstarted);
            Controls.Add(panel1);
            Controls.Add(label1);
            Controls.Add(lbEmail);
            FormBorderStyle = FormBorderStyle.None;
            Margin = new Padding(4, 5, 4, 5);
            Name = "Registration";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Registration";
            UseWaitCursor = true;
            Load += Registration_Load;
            panel1.ResumeLayout(false);
            panel1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox6).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox7).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox8).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label lbRegistration;
        private System.Windows.Forms.Button btnstarted;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lbEmail;
        private System.Windows.Forms.TextBox txtFullname;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtPass;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtConfirmPass;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtusername;
        private System.Windows.Forms.TextBox txtphone;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.PictureBox pictureBox8;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Timer timer1;
    }
}